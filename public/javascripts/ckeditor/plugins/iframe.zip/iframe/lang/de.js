// Video Dialog
CKEDITOR.plugins.setLang( 'iframe', 'de',
	{
		iframe :
		{
			title: 'Iframe-Eigentschaften',
			contextLabel: 'iframe editieren',
			hover: 'iframe einfügen/editieren',
			height: 'Framehöhe',
			validateHeight: 'Sie müssen eine gultige Framehöhe geben',
			width: 'Framebreite',
			validateWidth: 'Sie müssen eine gultige Framebreite geben',
			validateSrc: 'Bitte geben sie ein URL',
			scrolling: 'Blätterleisten einschalten',
			border: 'iframe Blattrand zeigen'
		}
	}
)

